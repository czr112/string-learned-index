# Model16 read-only snapshot: private reproducibility bundle

This is the exact source closure of the accepted snapshot factory at421eb36.
Context16 remains production default. Only bulk_load/find/owning scan are supported;
mutations and range_sum throw. Model commit and all source hashes are in manifest.json.
Functionality/space passed; no elapsed-performance or adoption claim is made.

Rebuild from this directory with an x86-64-v3-capable GCC toolchain and Python3.10+:

    python3 -I -B rebuild.py --output fresh_opt
    python3 -I -B rebuild.py --output fresh_san --sanitize

Each output directory must be new. The script needs no Git, network, dataset or
original workspace; Python standard library and the system C++ toolchain are needed.
It scans actual dependencies, rejects source outside this bundle, hashes tools and
sources, atomically publishes the binary and runs the same127-check public contract.
The sanitizer run requires the system GCC ASan/UBSan runtimes. Raw logs and hashes
remain in each fresh output directory, including failures.

This source-only contract rebuild does not repeat the original32/fault/space matrix.
See provenance.json and THIRD_PARTY_NOTICES.txt for original evidence and source origins.
