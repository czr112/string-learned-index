#include "bm_followup_memory.hpp"
int main(){auto* p=static_cast<volatile unsigned char*>(::operator new(8));p[8]=1;return p[0];}
