#include "bm_native_runtime.hpp"
#define ACCEPTANCE_FACTORY_HEADER "bm_tx_adapter.hpp"
#define ACCEPTANCE_FACTORY_SYMBOL make_bm_tx_experiment_index
#define main bm_native_contract_entry
#include "borrowed_contract_acceptance.cpp"
#undef main
int main(){try{const int status=bm_native_contract_entry();if(status)return status;
std::cout<<"NATIVE_RUNTIME ";bm_native_runtime::emit_modules();std::cout<<std::endl;return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<std::endl;return 1;}}
