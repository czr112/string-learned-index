#include "bm_native_runtime.hpp"
#define ACCEPTANCE_FACTORY_HEADER "bm_model16_snapshot_adapter.hpp"
#define ACCEPTANCE_FACTORY_SYMBOL make_bm_model16_snapshot_index
#define main paired_contract_entry
#include "borrowed_contract_acceptance.cpp"
#undef main
int main(){try{const auto rc=paired_contract_entry();if(rc)return rc;
std::cout<<"NATIVE_RUNTIME ";bm_native_runtime::emit_modules();std::cout<<std::endl;return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<std::endl;return 1;}}
