#define ACCEPTANCE_FACTORY_HEADER "bm_tx_adapter.hpp"
#define ACCEPTANCE_FACTORY_SYMBOL make_bm_tx_experiment_index
#include "borrowed_contract_acceptance.cpp"
