// Read-only review fixture: demonstrate whether an allocation failure preserves a page.
// The candidate and model sources are used without modification.
#include "bm_n1_page_core.hpp"
#include <cstdlib>
#include <iostream>
#include <new>
#include <string>
#include <vector>

static bool fail_next_new = false;
void* operator new(std::size_t n) {
    if (fail_next_new) {
        fail_next_new = false;
        throw std::bad_alloc();
    }
    if (void* p = std::malloc(n ? n : 1)) return p;
    throw std::bad_alloc();
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }

int main() {
    std::vector<static_physical::Row> rows;
    for (std::uint64_t i = 0; i < 1024; ++i)
        rows.push_back({"key" + std::to_string(1000000 + i).substr(1), i});
    bm_n1_leaf::Page page(rows);
    const auto first = page.try_insert("key000001a", 9001);
    if (first != bm_n1_leaf::Page::Insert::inserted) return 3;
    page.verify();
    const auto blocks_before = page.block_count();
    const auto bytes_before = page.memory().total();
    bool threw_bad_alloc = false;
    fail_next_new = true;
    try {
        page.try_insert("key000001b", 9002);
    } catch (const std::bad_alloc&) {
        threw_bad_alloc = true;
    }
    fail_next_new = false;
    std::size_t missing = 0;
    for (const auto& row : rows)
        if (page.find_base(row.key) != std::optional<std::uint64_t>(row.value)) ++missing;
    bool verify_ok = true;
    std::string verify_error;
    try { page.verify(); }
    catch (const std::exception& e) { verify_ok = false; verify_error = e.what(); }
    std::cout << std::boolalpha
              << "{\"threw_bad_alloc\":" << threw_bad_alloc
              << ",\"old_rows\":" << rows.size()
              << ",\"missing_old_rows_after_failure\":" << missing
              << ",\"verify_ok\":" << verify_ok
              << ",\"verify_error\":\"" << verify_error << "\""
              << ",\"blocks_before\":" << blocks_before
              << ",\"blocks_after\":" << page.block_count()
              << ",\"self_bytes_before\":" << bytes_before
              << ",\"self_bytes_after\":" << page.memory().total()
              << ",\"rollback_preserved\":" << (threw_bad_alloc && missing == 0 && verify_ok)
              << "}\n";
    // Success here means that the review reproduced the defect, not that the gate passed.
    return threw_bad_alloc && missing > 0 && !verify_ok ? 0 : 2;
}
